character(dog).
character(person1).
character(person2).
character(person3).
character(person4).

title(czterejPancerniIPies).
subtitle(naPodstawiePowiesciJanuszaPrzymanowskiego).

helmet(green).
helmet(gray).
helmet(without).

facialHair(mustache).
facialHair(shaved).
facialHair(coat).

wearsAHelmet(dog, without).
wearsAHelmet(person1, green).
wearsAHelmet(person2, green).
wearsAHelmet(person3, green).
wearsAHelmet(person4, gray).

haveFacialHair(dog, coat).
haveFacialHair(person1, shaved).
haveFacialHair(person2, shaved).
haveFacialHair(person3, shaved).
haveFacialHair(person4, mustache).



