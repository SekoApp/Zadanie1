character(person1).
character(person2).
character(person3).

sunglasses(aviator).
sunglasses(wayfarer).

purse(blue).
purse(white).

dress(gold).
dress(white).
dress(grid).

shoes(flip-flops).
shoes(sandals).

wearsASunglasses(person1, wayfarer).
wearsASunglasses(person2, aviator).
wearsASunglasses(person3, wayfarer).

wearsAPurse(person1, blue).
wearsAPurse(person2, white).
wearsAPurse(person3, blue).

wearsADress(person1, gold).
wearsADress(person2, white).
wearsADress(person3, grid).

wearsAShoes(person1, flip-flops).
wearsAShoes(person2, flip-flops).
wearsAShoes(person3, sandals).