character(person1).
character(person2).
character(person3).
character(person4).
character(person5).
character(person6).

title(friends).

female(person2; person4; person6).
male(person1; person4; person5).

hair(blonde).
hair(brunette).

haveHair(person1, brunette).
haveHair(person2, blonde).
haveHair(person3, brunette).
haveHair(person4, brunette).
haveHair(person5, brunette).
haveHair(person6, blonde).

drinkLeftShake(person1; person2; person3).
drinkRightShake(person4; person5; person6).



